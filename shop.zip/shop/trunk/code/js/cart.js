var checkboxLen;
var checkedLen = 0;
$(function() {
	var checkbox = document.getElementsByClassName('mycheckbox')
	checkboxLen = checkbox.length;
})

// 多选框-统一
$(document).on('click', '.checkbox', function() {
	if ($(this)[0].checked) {
		// 需变 选中
		$(this).prev().attr('src', 'images/cart/tick-s.png');
	} else {
		// 需变 不选中
		$(this).prev().attr('src', 'images/cart/tick.png');
	}
})


// 多选框-上面
$(document).on('change', '.mycheckbox', function() {
	checkedLen = 0;
	$(".mycheckbox").each(function(index, item) {
		if ($(this)[0].checked) {
			checkedLen++
		}
	});
	$(".checkedLen").html(checkedLen);
	if (checkedLen == checkboxLen) {
		$(".allselect").prop('checked', true);
		$(".allselect").prev().attr('src', 'images/cart/tick-s.png');
	} else {
		$(".allselect").prop('checked', false);
		$(".allselect").prev().attr('src', 'images/cart/tick.png');
	}
	total();
})

// 多选框-全选
$(document).on('click', '.allselect', function() {
	if ($(this)[0].checked) {
		// 需变 选中
		$('.tick').attr('src', 'images/cart/tick-s.png');
		$('.checkbox').prop('checked', true);
	} else {
		// 需变 不选中
		$('.tick').attr('src', 'images/cart/tick.png');
		$('.checkbox').prop('checked', false);
	}
	checkedLen = 0;
	$(".mycheckbox").each(function(index, item) {
		if ($(this)[0].checked) {
			checkedLen++
		}
	});
	$(".checkedLen").html(checkedLen);
	total();
})


// 统计金额
function total() {
	var integer = 0;
	$(".mycheckbox").each(function(index, item) {
		if ($(this)[0].checked) {
			var price = Number($(this).parents('.cart-block').find('.price').html());
			var num = $(this).parents('.cart-block').find('.num-input').val();
			integer += price * num;
		}
	});
	integer = Math.floor(integer * 100) / 100;
	if (isInteger(integer)) {
		$('.integer').html(integer);
		$('.point').html('');
		return;
	}
	var str = integer.toString();
	var index = str.indexOf(".");
	var result = str.substr(index + 1, str.length);
	var integerStr = str.substr(0, index);
	$('.integer').html(integerStr);
	$('.point').html('.' + result);
}


// 数量增减
$(document).on('click', '.sub', function() {
	var val = $(this).parent().find('.num-input').val();
	if (val == 1) {
		return;
	}
	var num = Number(val) - 1;
	$(this).parent().find('.num-input').val(num);
	total();
})

$(document).on('click', '.add', function() {
	var val = $(this).parent().find('.num-input').val();
	var num = Number(val) + 1;
	$(this).parent().find('.num-input').val(num);
	total();
})

function isInteger(obj) {
	return obj % 1 === 0
}



// 编辑
$(document).on('click', '.cart-operation', function() {
	if ($(this).hasClass('edit')) {
		$(this).removeClass('edit');
		$(this).addClass('delete');
		$('.settlement').hide();
		$('.delete-btn').show();
		$(this).html('完成');
	} else {
		$('.settlement').css('display', 'flex');
		$('.delete-btn').hide();
		$(this).addClass('edit');
		$(this).removeClass('delete');
		$(this).html('编辑');
	}
})

//删除
$('.delete-btn button').click(function(){
	$(".mycheckbox").each(function(index, item) {
		var thch=$(this)[0].checked;
		if (thch) {
			$(this).parent().parent().remove();
		}
	});
	checkedLen = 0;
	$(".mycheckbox").each(function(index, item) {
		if ($(this)[0].checked) {
			checkedLen++
		}
	});
	$(".checkedLen").html(checkedLen);
	total();
});











//返回顶部功能函数封装
//
//
//

//当页面加载完成
$(function() {
    //把函数  挂载在window上  暴露出去
    window.gotoTop = function() {
        //准备结构
        var $gotoTopHtml = $('<div class="backtop"><sapn class="iconfont" style="font-size:35px">&#xe62a;</span></div>');

        //写样式定位
        $gotoTopHtml.css({
            position: 'fixed',
            bottom: '80px',
            right: '20px',
            // marginLeft: '50%',
            /* 默认隐藏 */
            //  display: none,
        });
        //返回顶部的js代码
        //绑定滚动事件
        $(document).scroll(function() {
                //获取距离顶部的位置
                var topDistance = $('html,body').scrollTop();
                //判断
                if (topDistance > 500) {
                    $('.backtop').fadeIn()
                } else {
                    $('.backtop').fadeOut()
                }
            })
            //返回顶部功能（动态添加的元素  需要使用事件委托  才能绑定事件）    
        $('body').on('click', '.backtop', function() {
                $('html, body').animate({
                    scrollTop: 0
                }, 300)
            })
            //追加到页面的尾部
        $('body').append($gotoTopHtml)
    }
})
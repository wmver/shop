
/* 图书导航图 */
$.fn.bookcen = function() {
	var book_cen_list = document.getElementById("book_cen_list");
	var inner = book_cen_list.children[0];
	var ulObj = inner.children[0];
	var spanObjs = inner.children[1].children;
	var imgWidth = inner.offsetWidth;
	for (var i = 0; i < spanObjs.length; i++) {
		spanObjs[i].setAttribute("index", i);
		spanObjs[i].onmouseover = function() {
			for (var j = 0; j < spanObjs.length; j++) {
				// 所有span的进入都清空
				spanObjs[j].removeAttribute("class");
			}
			this.className = "current";
			var index = this.getAttribute("index");
			animate(ulObj, -imgWidth * index);
		};
		spanObjs[i].onmouseout = function() {}
	}

	function animate(element, target) {
		clearInterval(element.timeId);
		element.timeId = setInterval(function() {
			var step = 10;
			var current = element.offsetLeft;
			step = current < target ? step : -step;
			current += step;
			if (Math.abs(current - target) > Math.abs(step)) {
				element.style.left = current + "px";
			} else {
				clearInterval(element.timeId);
				element.style.left = target + "px";
			}
		}, 30);
	}
};




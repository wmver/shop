$(function() {
    var index = 0;
    $('.guess_ch').click(function() {
            // 自增
            index++;
            // 边界判断
            index = index > 2 ? 0 : index;
            // 让里面的inner - box 运动
            $('.inner-box').animate({
                top: -index * 500
            })
        })
        //左右滑动的版本
        // var index = 0;
        // $('.guess_ch').click(function() {
        //     //自增
        //index++;
        //     //边界判断
        //     //让里面的inner-box 运动
        //     $('.inner-box').stop(true).animate({ left: -index * 1200 }, function() {
        //         if (index === 3) {
        //             index = 0;
        //             $('.inner-box').css('left', 0);
        //         }
        //     })
        // })
})
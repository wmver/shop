//幻灯片
$(function() {
	jQuery("#slider-3 .slider").slide({
		mainCell: ".bd ul",
		titCell: ".hd li",
		trigger: "click",
		effect: "leftLoop",
		autoPlay: true,
		delayTime: 700,
		interTime: 7000,
		pnLoop: false,
		titOnClassName: "active"
	})
});

//横向滚动
$(function() {
	$(".price_box").jCarouselLite({
		auto: 2000,
		/*自动播放间隔时间*/
		speed: 500,
		/*速度*/
		btnNext: ".next",
		/*向前滚动*/
		btnPrev: ".prev",
		/*向后滚动*/
		visible: 5 /*显示数量*/
	})
});

// 顶部搜索框交互
$(document).scroll(function() {
	//获取到顶部的距离 
	var topDistance = $('html,body').scrollTop();
	//判断
	if (topDistance > 500) {
		//如果滚动距离大于500 滑下来
		$('.hid_black_nav').slideDown(300)
	} else {
		//否则  收回去
		$('.hid_black_nav').slideUp(300)
	}
})

// 图书轮播图
$('#book_cen_list').bookcen();







window.onload = function() {
	/**
	 * @desc 函数防抖
	 * @param func 函数
	 * @param wait 延迟执行毫秒数
	 * @param immediate true 表立即执行，false 表非立即执行
	 * 作者：淘淘笙悦
	 * 链接：https://www.jianshu.com/p/c8b86b09daf0
	 * 来源：简书
	 * 著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
	 */
/* 	function debounce(func, wait, immediate) {
		let timeout;
		return function() {
			let context = this;
			let args = arguments;
			console.log(1)
			if (timeout) clearTimeout(timeout);
			if (immediate) {
				var callNow = !timeout;
				timeout = setTimeout(() => {
					timeout = null;
				}, wait)
				if (callNow) func.apply(context, args)
			} else {
				timeout = setTimeout(function() {
					func.apply(context, args)
				}, wait);
			}
		}
	}

	function bookRi() {
		// $('.br_main>li').mouseenter(function() {
		$(this).siblings().find('.br_hi').slideUp(); //隐藏详情
		$(this).siblings().find('.br_ti').slideDown(); //显示标题
		$(this).find('.br_ti').slideUp(); //隐藏标题 
		$(this).find('.br_hi').slideDown(); //显示详情
		// });
	}

	var bookRight = document.getElementById(brmain);
	bookRight.onmousemove = debounce(bookRi(), 2000, true); */
	
	

	
	
	
};



	//处理函数

	$('.br_main>li').mouseenter(function() {
		var timeout;
		var bla = this;
		var bookRi = function() {
			$(bla).siblings().find('.br_hi').slideUp(); //隐藏详情
			$(bla).siblings().find('.br_ti').slideDown(); //显示标题
			$(bla).find('.br_ti').slideUp(); //隐藏标题 
			$(bla).find('.br_hi').slideDown(); //显示详情
		}
		console.log(timeout)
		timeout = setTimeout(bookRi(), 5000);
		console.log(timeout+'set')
		if (timeout !== null) {
			var l = clearTimeout(timeout); //清除这 个定时器
			console.log(l)
		}
		var debounce = function(fn, wait) {
			timeout = null; //定 义一个定时器
			console.log(timeout+'null')
		}
		debounce(bookRi(), 5000);
	});

    //楼层跳转功能
    $('.floor li').click(function() {
        //获取索引
        var index = $(this).index();
        //选中每一个板块到顶部的偏移
        var topOffset = $('.floorBox').eq(index).offset().top;

        //让滚动条滚到这个位置
        $('html,body').animate({
            scrollTop: topOffset - 50
        })
    })

// book手风琴
/* function bookRight(){
	//所有兄弟:隐藏详情 显示标题
	$(this).siblings().find('.br_hi').slideUp(); //隐藏详情
	$(this).siblings().find('.br_ti').slideDown(); //显示标题
	
	//当前:隐藏标题  显示详情
	$(this).find('.br_ti').slideUp(); //隐藏标题 
	$(this).find('.br_hi').slideDown(); //显示详情
}

$('.br_main>li').onmousemove = 	debounce(bookRight(),2000,true);;	
 */

// 二维码滑出效果
$('.rn_coupon').hover(function() {
	//让二维码画出来
	$('.rn_coupon>div').stop().animate({
		// bottom: '-=100px'
		top:'0px'
	})
}, function() {
	//让二维码收回去
	$('.rn_coupon>div').stop().animate({
		// bottom: '+=101px'
		top:'-100px'
	})
});

// 商品详情div
var goods_info = function(){
	$(".goods_info").attr("style","display:block");
}

$(".goods_info").mouseup(function(e){
  var _con = $('.product-detail');   // 设置目标区域
  if(!_con.is(e.target) && _con.has(e.target).length === 0){ // Mark 1
     $(".goods_info").attr("style","display:none");
  }
});
// 注册div
var register = function(){
	$(".register").attr("style","display:block");
}

$(".register").mouseup(function(e){
  var _con = $('.register>div');   // 设置目标区域
  if(!_con.is(e.target) && _con.has(e.target).length === 0){ // Mark 1
     $(".register").attr("style","display:none");
  }
});

























